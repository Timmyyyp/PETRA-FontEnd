from django.shortcuts import render,HttpResponse

# Create your views here.
def Index(request):
    return render(request, "Index.html")

def Login(request):
    return render(request, "Login.html")

def Register(request):
    return render(request, "Register.html")

def DoctorLogin(request):
    return render(request, "DoctorLogin.html")

def Home(request):
    return render(request, "Home.html")

def Game(request):
    return render(request, "Game.html")
