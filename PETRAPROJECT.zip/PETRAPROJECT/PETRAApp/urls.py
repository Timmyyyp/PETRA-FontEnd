from django.urls import path
from . import views

urlpatterns = [
    path("index", views.Index, name="Index"),
    path("home", views.Home, name="Home"),
    path("login", views.Login, name="Login"),
    path("register", views.Register, name="Register"),
    path("doctorLogin", views.DoctorLogin, name="DoctorLogin"),
    path("game", views.Game, name="Game"),
]